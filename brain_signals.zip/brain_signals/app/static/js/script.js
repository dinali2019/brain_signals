var socket = io.connect('http://' + document.domain + ':' + location.port);

socket.on('coffee_choice', function(data) {
    document.getElementById('coffee-choice').innerText = "You should drink: " + data.coffee;
});

// Send EEG data periodically (simulated here)
setInterval(() => {
    let data = {
        alpha: Math.random(),
        beta: Math.random(),
        gamma: Math.random(),
        delta: Math.random()
    };
    socket.emit('brainwave_data', data);
}, 3000);
