from flask import Flask, render_template
from flask_socketio import SocketIO
import numpy as np

app = Flask(__name__)
socketio = SocketIO(app)

# Dummy function to process brain signals and choose coffee
def get_coffee_choice(alpha, beta, gamma, delta):
    # Logic to determine coffee choice based on brainwave intensity
    if alpha > 0.5:
        return 'Espresso'
    elif beta > 0.5:
        return 'Latte'
    elif gamma > 0.5:
        return 'Cappuccino'
    elif delta > 0.5:
        return 'Mocha'
    else:
        return 'Espresso'

@app.route('/')
def index():
    return render_template('index.html')

# SocketIO event to receive EEG data and send coffee choice
@socketio.on('brainwave_data')
def handle_brainwave_data(data):
    alpha, beta, gamma, delta = data['alpha'], data['beta'], data['gamma'], data['delta']
    coffee_choice = get_coffee_choice(alpha, beta, gamma, delta)
    socketio.emit('coffee_choice', {'coffee': coffee_choice})

if __name__ == '__main__':
    socketio.run(app, debug=True)
