import muselsl
import time
import json
import socket

# Set the IP and port of the Flask server
FLASK_SERVER_IP = '127.0.0.1'
FLASK_SERVER_PORT = 5000

# Create a socket to communicate with Flask server
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((FLASK_SERVER_IP, FLASK_SERVER_PORT))

def send_eeg_data_to_flask(alpha, beta, gamma, delta):
    """ Send the processed EEG data to the Flask server via socket. """
    data = {
        'alpha': alpha,
        'beta': beta,
        'gamma': gamma,
        'delta': delta
    }
    client_socket.sendall(json.dumps(data).encode())

def collect_and_process_data():
    """ Collect EEG data and process it. """
    while True:
        # Collect raw EEG data using muselsl
        raw_data = muselsl.get_data()

        # Process the raw data (FFT, filtering, etc.)
        # You should extract and calculate alpha, beta, gamma, delta from raw_data here
        alpha = np.random.random()  # Replace with actual processing logic
        beta = np.random.random()   # Replace with actual processing logic
        gamma = np.random.random()  # Replace with actual processing logic
        delta = np.random.random()  # Replace with actual processing logic

        # Send the processed data to Flask
        send_eeg_data_to_flask(alpha, beta, gamma, delta)
        
        time.sleep(3)  # Sleep for 3 seconds before sending the next set of data

if __name__ == '__main__':
    collect_and_process_data()
